# Wrapped-Torch-Training
Wrapped Torch Training programme which is easy to use
